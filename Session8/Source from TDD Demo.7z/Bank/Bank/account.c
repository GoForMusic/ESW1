#include <stdlib.h>
#include "account.h"

typedef struct account_st {
	double ballance;
}account_st;

account_t account_create() {
	account_t self = calloc(sizeof(account_st), 1);

	if (self == NULL) {
		return 0;
	}

	return self;
}

void account_destroy(account_t self) {
	if (self == NULL) {
		return;
	}

	free(self);
}

account_status_t account_deposit(account_t self, double amount) {
	if (amount >= 0) {
		self->ballance += amount;
		return ACCOUNT_OK;
	}

	return ACCOUNT_NEGATIVE_AMOUNT_NOT_LEGAL;
}

account_status_t account_withdraw(account_t self, double amount) {
	if (amount <= self->ballance) {
		self->ballance -= amount;
		return ACCOUNT_OK;
	}

	return ACCOUNT_INSUFFICIENT_BALLANCE;
}

double account_getBalance(account_t self) {
	return self->ballance;
}