#pragma once

typedef struct account_st* account_t;

typedef enum {
	ACCOUNT_OK
	, ACCOUNT_INSUFFICIENT_BALLANCE
	, ACCOUNT_NEGATIVE_AMOUNT_NOT_LEGAL
} account_status_t;

account_t account_create();
void account_destroy(account_t self);

account_status_t account_deposit(account_t self, double amount);
account_status_t account_withdraw(account_t self, double amount);
double account_getBalance(account_t self);
