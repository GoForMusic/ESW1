#include <gtest/gtest.h>

extern "C" {
#include <account.h>
}

class AccountTest : public ::testing::Test {
protected:
	account_t uut;

	void SetUp() override {
		uut = account_create();
	}

	void TearDown() override {
		account_destroy(uut);
	}
};

	TEST_F(AccountTest, BalanceIsZeroWhenAccountCreated) {
		EXPECT_DOUBLE_EQ(0.0, account_getBalance(uut));
	}

	TEST_F(AccountTest, PositiveDepositIsAllowed) {
		account_status_t rc = account_deposit(uut,1.0);

		EXPECT_EQ(ACCOUNT_OK, rc);
	}

	TEST_F(AccountTest, MultiblePositiveDepositIsIncreasingBallance) {
		account_deposit(uut, 1.0);
		account_deposit(uut, 1.0);

		EXPECT_DOUBLE_EQ(2.0, account_getBalance(uut));
	} 

	TEST_F(AccountTest, BalanceIsIncreacedWithDepositAmount) {
		account_status_t rc = account_deposit(uut,1.0);

		EXPECT_DOUBLE_EQ(1.0, account_getBalance(uut));
	}

	TEST_F(AccountTest, PossibleToWithdrawIfBallanceIsPositive) {
		account_status_t rc = account_deposit(uut,1.0);
		rc =  account_withdraw(uut, 1.0);

		EXPECT_EQ(ACCOUNT_OK, rc);
	}

	TEST_F(AccountTest, NotPossibleToWithdrawIfBallanceTurnsNegative) {
		account_status_t rc = account_deposit(uut,1.0);
		rc = account_withdraw(uut, 2.0);

		EXPECT_EQ(ACCOUNT_INSUFFICIENT_BALLANCE, rc);
	}

	TEST_F(AccountTest, BallanceIsDecreasedWitdrwnAmount) {
		account_status_t rc = account_deposit(uut,10.0);
		rc = account_withdraw(uut, 2.0);

		EXPECT_DOUBLE_EQ(8.0, account_getBalance(uut));
	}

	TEST_F(AccountTest, BallanceIsUntouchedWhenWithdrawMoreThanBalance) {
		account_deposit(uut, 1.0);
		account_withdraw(uut, 2.0);

		EXPECT_DOUBLE_EQ(1.0, account_getBalance(uut));
	}


	TEST_F(AccountTest, NegativeDepositIsNotAllowed) {
		account_status_t rc = account_deposit(uut, -1.0);

		EXPECT_EQ(ACCOUNT_NEGATIVE_AMOUNT_NOT_LEGAL, rc);
	}